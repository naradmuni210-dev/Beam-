package com.example.rccbeam.calc

import kotlin.math.sqrt
import kotlin.math.PI

data class BeamInput(
    val b_mm: Double,
    val D_mm: Double,
    val cover_mm: Double,
    val fck: Double,
    val fy: Double,
    val Mu_kNm: Double,
    val w_kNpm: Double? = null,
    val span_m: Double? = null,
    val shear_V_kN: Double? = null
)

data class BeamResult(
    val d_mm: Double,
    val xu_mm: Double?,
    val Ast_mm2: Double?,
    val providedBars: String?,
    val Ast_min_mm2: Double,
    val shearCheck: ShearResult?,
    val isDoublyReinforced: Boolean,
    val notes: String
)

data class ShearResult(
    val V_kN: Double,
    val tau_v_Nmm2: Double,
    val tau_c_Nmm2: Double,
    val shearOK: Boolean,
    val recommended: String
)

fun designBeamWithDoublyLogic(input: BeamInput): BeamResult {
    val b = input.b_mm
    val D = input.D_mm
    val cover = input.cover_mm
    val fck = input.fck
    val fy = input.fy
    val Mu_Nmm = input.Mu_kNm * 1e6

    val d = D - cover
    val xuLimRatio = 0.48
    val xu_lim = xuLimRatio * d

    val C_lim = 0.36 * fck * b * xu_lim
    val z_lim = d - 0.42 * xu_lim
    val Mu_singly_limit_Nmm = C_lim * z_lim

    val Ast_min = (0.85 * b * d) / fy

    val A = -0.36 * fck * b * 0.42
    val B = 0.36 * fck * b * d
    val C = -Mu_Nmm

    val standardBars = listOf(
        25.0 to (PI * 25.0 * 25.0 / 4.0),
        20.0 to (PI * 20.0 * 20.0 / 4.0),
        16.0 to (PI * 16.0 * 16.0 / 4.0),
        12.0 to (PI * 12.0 * 12.0 / 4.0),
        10.0 to (PI * 10.0 * 10.0 / 4.0)
    )

    val disc = B * B - 4.0 * A * C
    if (disc >= 0) {
        val sqrtDisc = sqrt(disc)
        val xu1 = (-B + sqrtDisc) / (2.0 * A)
        val xu2 = (-B - sqrtDisc) / (2.0 * A)
        val xuCandidate = listOf(xu1, xu2).filter { it > 0.0 && it < d }.minOrNull()
        if (xuCandidate != null) {
            val xu = xuCandidate
            val Ast = (0.36 * fck * b * xu) / (0.87 * fy)
            if (Mu_Nmm <= Mu_singly_limit_Nmm * 1.0001) {
                val provided = suggestBars(Ast, standardBars)
                val shearRes = computeShearIfRequested(input, b, d, fck)
                val notes = buildString {
                    appendLine("Singly reinforced design used.")
                    appendLine("Singly moment limit Mu_singly = ${"%.2f".format(Mu_singly_limit_Nmm/1e6)} kN·m (using xu_lim=${"%.2f".format(xu_lim)} mm).")
                    appendLine("Check minimum steel and shear as per IS 456.")
                }
                val finalAst = if (Ast < Ast_min) Ast_min else Ast
                return BeamResult(
                    d_mm = d,
                    xu_mm = xu,
                    Ast_mm2 = finalAst,
                    providedBars = provided,
                    Ast_min_mm2 = Ast_min,
                    shearCheck = shearRes,
                    isDoublyReinforced = false,
                    notes = notes
                )
            }
        }
    }

    val Cc = 0.36 * fck * b * xu_lim
    val Mu_by_concrete = Cc * (d - 0.42 * xu_lim)

    if (Mu_by_concrete >= Mu_Nmm) {
        val xu = xu_lim
        val Ast_fromC = (Cc) / (0.87 * fy)
        val provided = suggestBars(Ast_fromC, standardBars)
        val shearRes = computeShearIfRequested(input, b, d, fck)
        val finalAst = if (Ast_fromC < Ast_min) Ast_min else Ast_fromC
        val notes = "Edge case: concrete compression alone resists Mu. Treated as singly reinforced with xu = xu_lim."
        return BeamResult(d, xu, finalAst, provided, Ast_min, shearRes, false, notes)
    }

    val Mu_extra = Mu_Nmm - Mu_by_concrete
    val dPrime = cover + 10.0
    val lever_arm_for_Asc = d - dPrime
    val Asc = Mu_extra / (0.87 * fy * lever_arm_for_Asc)
    val Ast_total = (Cc) / (0.87 * fy) + Asc
    val Ast_final = if (Ast_total < Ast_min) Ast_min else Ast_total
    val providedBars = suggestBars(Ast_final, standardBars)
    val shearRes = computeShearIfRequested(input, b, d, fck)

    val notes = buildString {
        appendLine("Doubly reinforced design selected (Mu exceeds singly limit).")
        appendLine("Assumptions used:")
        appendLine("- xu_lim ratio = ${"%.3f".format(xuLimRatio)} (xu_lim = ${"%.1f".format(xu_lim)} mm).")
        appendLine("- Compression block force Cc = ${"%.1f".format(Cc)} N")
        appendLine("- Compression steel centroid assumed at d' = ${"%.1f".format(dPrime)} mm.")
        appendLine("- Minimum steel Ast_min = ${"%.1f".format(Ast_min)} mm² enforced if required.")
        appendLine("Recommendation: verify detailed IS 456 clause values and check detailing (stirrups, spacing, anchorage).")
    }

    return BeamResult(
        d_mm = d,
        xu_mm = xu_lim,
        Ast_mm2 = Ast_final,
        providedBars = providedBars,
        Ast_min_mm2 = Ast_min,
        shearCheck = shearRes,
        isDoublyReinforced = true,
        notes = notes
    )
}

private fun suggestBars(AstRequired: Double, standardBars: List<Pair<Double, Double>>): String {
    for ((dia, area) in standardBars) {
        for (count in 1..6) {
            if (count * area >= AstRequired) {
                return "${count}✕${dia.toInt()}mm (area=${"%.1f".format(count*area)} mm²)"
            }
        }
    }
    return "Use multiple bars totalling ≥ ${"%.1f".format(AstRequired)} mm²"
}

private fun computeShearIfRequested(input: BeamInput, b: Double, d: Double, fck: Double): ShearResult? {
    val V_kN = when {
        input.shear_V_kN != null -> input.shear_V_kN
        input.w_kNpm != null && input.span_m != null -> input.w_kNpm * input.span_m / 2.0
        else -> null
    } ?: return null

    val V_N = V_kN * 1000.0
    val tau_v = V_N / (b * d)
    val tau_c = 0.28 * sqrt(fck)
    val shearOK = tau_v <= tau_c
    val recommended = if (shearOK) {
        "No shear reinforcement required by quick check (verify per IS 456)."
    } else {
        "Shear reinforcement (stirrups) required. Provide as per IS 456 spacing rules."
    }

    return ShearResult(V_kN, tau_v, tau_c, shearOK, recommended)
}