package com.example.rccbeam.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.rccbeam.calc.BeamInput
import com.example.rccbeam.calc.designBeamWithDoublyLogic

@Composable
fun BeamDesignScreen() {
    var b by remember { mutableStateOf("230") }
    var D by remember { mutableStateOf("500") }
    var cover by remember { mutableStateOf("40") }
    var fck by remember { mutableStateOf("25") }
    var fy by remember { mutableStateOf("500") }
    var span by remember { mutableStateOf("4.5") }
    var w by remember { mutableStateOf("20") }
    var MuInput by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("Enter inputs and tap DESIGN") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Beam Design (Singly/Doubly) — IS style", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value = b, onValueChange = { b = it }, label = { Text("Breadth b (mm)") }, singleLine = true)
        OutlinedTextField(value = D, onValueChange = { D = it }, label = { Text("Overall depth D (mm)") }, singleLine = true)
        OutlinedTextField(value = cover, onValueChange = { cover = it }, label = { Text("Effective cover (mm)") }, singleLine = true)
        OutlinedTextField(value = fck, onValueChange = { fck = it }, label = { Text("Concrete fck (MPa)") }, singleLine = true)
        OutlinedTextField(value = fy, onValueChange = { fy = it }, label = { Text("Steel fy (MPa)") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = span, onValueChange = { span = it }, label = { Text("Span (m)") }, singleLine = true, modifier = Modifier.weight(1f))
            OutlinedTextField(value = w, onValueChange = { w = it }, label = { Text("UDL w (kN/m)") }, singleLine = true, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(value = MuInput, onValueChange = { MuInput = it }, label = { Text("Or Moment Mu (kN·m) — optional") }, singleLine = true)
        Button(onClick = {
            try {
                val mu = if (MuInput.isNotBlank()) MuInput.toDouble() else {
                    val spanD = span.toDouble()
                    val wD = w.toDouble()
                    (wD * spanD * spanD) / 8.0
                }
                val inputObj = BeamInput(
                    b_mm = b.toDouble(),
                    D_mm = D.toDouble(),
                    cover_mm = cover.toDouble(),
                    fck = fck.toDouble(),
                    fy = fy.toDouble(),
                    Mu_kNm = mu,
                    w_kNpm = if (w.isNotBlank()) w.toDouble() else null,
                    span_m = if (span.isNotBlank()) span.toDouble() else null
                )
                val res = designBeamWithDoublyLogic(inputObj)

                resultText = buildString {
                    appendLine("Effective depth d = ${"%.1f".format(res.d_mm)} mm")
                    appendLine(if (res.isDoublyReinforced) "Design type: DOUBLY REINFORCED" else "Design type: SINGLY REINFORCED")
                    appendLine("Ast required = ${if (res.Ast_mm2 != null) "%,.1f".format(res.Ast_mm2) + " mm²" else "—"}")
                    appendLine("Ast_min = ${"%.1f".format(res.Ast_min_mm2)} mm²")
                    appendLine("Provided bars suggestion: ${res.providedBars ?: "—"}")
                    if (res.xu_mm != null) appendLine("Neutral axis xu = ${"%.2f".format(res.xu_mm)} mm")
                    res.shearCheck?.let { sh ->
                        appendLine("--- Shear check ---")
                        appendLine("V = ${"%.2f".format(sh.V_kN)} kN")
                        appendLine("τv = ${"%.3f".format(sh.tau_v_Nmm2)} N/mm² ; τc (approx) = ${"%.3f".format(sh.tau_c_Nmm2)} N/mm²")
                        appendLine("Shear OK? : ${if (sh.shearOK) "YES" else "NO"} -> ${sh.recommended}")
                    }
                    appendLine("--- Notes & Assumptions ---")
                    appendLine(res.notes)
                    appendLine("IMPORTANT: These calculations use engineering approximations. Verify final detailing, spacing, and clause references as per IS 456:2000 and IS 875.")
                }
            } catch (e: Exception) {
                resultText = "Error: ${e.localizedMessage}"
            }
        }) {
            Text("DESIGN")
        }
        Spacer(Modifier.height(8.dp))
        Text(resultText)
    }
}