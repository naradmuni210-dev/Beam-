# RCC Beam Designer - Android (Kotlin + Compose)
This project is a minimal Android Studio skeleton for a beam design calculator (singly/doubly reinforced) using IS-style formulas.

## What's included
- Calculation engine: `BeamCalculator.kt`
- Compose UI: `BeamDesignScreen.kt`
- MainActivity to run the Compose UI

## How to build APK (locally)
1. Install Android Studio and the Android SDK (recommended).
2. Open this folder in Android Studio (`File -> Open`).
3. Let Android Studio sync Gradle. If Gradle wrapper files are missing, run `gradle wrapper` or create a wrapper in Android Studio.
4. To build a debug APK:
   - From terminal: `./gradlew :app:assembleDebug`
   - Or from Android Studio: Run -> Select app -> Run
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## How to produce a release-signed APK
1. Create a keystore:
   ```
   keytool -genkey -v -keystore release-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias rccbeamkey
   ```
2. Configure signing in `app/build.gradle.kts` or use Android Studio's Build -> Generate Signed Bundle / APK.
3. Build release: `./gradlew :app:assembleRelease`

## Notes
- I cannot build APKs inside this environment. You must build locally on your machine or CI.
- If you want, I can provide a GitHub Actions workflow to build APKs automatically when you push the repo.