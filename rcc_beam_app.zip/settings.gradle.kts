rootProject.name = "RCCBeamApp"
include(":app")